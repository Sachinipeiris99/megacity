package com.example.megacitycab.service.observer;

public interface Observer {
    void update(String message);
}
